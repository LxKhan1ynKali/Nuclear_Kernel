# Nuclear Kernel v8.9.0 Installation Guide

## 🚀 Complete Installation and Setup Instructions

### Author: lxkhanin
### Version: 8.9.0 "Neural Nexus Quantum"
### Updated: 2024-09-20

---

## 📋 Prerequisites Check

### System Requirements

| Component | Requirement | Command to Check |
|-----------|------------|------------------|
| **OS** | Kali Linux / Ubuntu 20.04+ / Debian 11+ | `lsb_release -a` |
| **RAM** | Minimum 4GB (8GB+ recommended) | `free -h` |
| **Storage** | At least 3GB free space | `df -h` |
| **Architecture** | x86_64 | `uname -m` |

### Software Dependencies

```bash
# Update package manager
sudo apt update && sudo apt upgrade -y

# Install essential build tools
sudo apt install -y \
    build-essential \
    g++ \
    make \
    cmake \
    git \
    python3 \
    python3-pip \
    python3-dev \
    libc6-dev \
    linux-headers-$(uname -r)

# Verify installations
g++ --version     # Should be 7.0+ with C++17 support
make --version    # GNU Make 4.0+
python3 --version # Python 3.8+
```

---

## 📦 Installation Methods

### Method 1: From ZIP Package (Recommended)

1. **Download and Extract**
   ```bash
   cd /home/kali/Desktop
   
   # If you have the ZIP file
   unzip nuclear-kernel-v8.9.0.zip
   cd nuclear-kernel-v8.9.0
   
   # Verify extraction
   ls -la
   # Should show: src/ include/ lib/ bin/ tools/ docs/ Makefile
   ```

2. **Set Permissions**
   ```bash
   # Make sure all files have correct permissions
   chmod +x Makefile
   chmod +x tools/*.cpp
   chmod -R 755 .
   ```

### Method 2: Build from Source (Advanced)

1. **Clone/Copy Source Files**
   ```bash
   cd /home/kali/Desktop
   mkdir nuclear-kernel-v8.9.0
   cd nuclear-kernel-v8.9.0
   
   # Copy all source files to this directory
   # Ensure you have: src/ include/ tools/ Makefile
   ```

---

## 🔧 Compilation Process

### Step 1: Clean Build Environment

```bash
cd /home/kali/Desktop/nuclear-kernel-v8.9.0

# Clean any previous builds
make clean

# Create necessary directories
mkdir -p build lib bin licenses
```

### Step 2: Compile Nuclear Kernel

```bash
# Option A: Full automatic build
make all

# Option B: Manual step-by-step build (if make fails)
echo "Building Nuclear Kernel manually..."

# Compile kernel source
g++ -std=c++17 -Wall -Wextra -O3 -march=native \
    -mtune=native -ffast-math -funroll-loops \
    -finline-functions -fomit-frame-pointer \
    -DNDEBUG -D_FORTIFY_SOURCE=2 \
    -fstack-protector-strong -fPIC -pthread \
    -Iinclude -c src/nuclear_kernel.cpp \
    -o build/nuclear_kernel.o

# Create shared library
g++ build/nuclear_kernel.o -o lib/libnuclear_kernel.so \
    -shared -pthread -ldl -lm

# Strip symbols for optimization
strip --strip-unneeded lib/libnuclear_kernel.so

# Build license generator
g++ -std=c++17 -O3 -march=native -Iinclude \
    tools/license_generator.cpp \
    -o bin/nuclear_license_gen \
    -Llib -lnuclear_kernel -ldl -lm

echo "✅ Nuclear Kernel v8.9.0 compiled successfully!"
```

### Step 3: Verify Compilation

```bash
# Check compiled files
ls -la lib/libnuclear_kernel.so
ls -la bin/nuclear_license_gen

# Check library dependencies
LD_LIBRARY_PATH=./lib ldd lib/libnuclear_kernel.so

# Test library loading
LD_LIBRARY_PATH=./lib ldd bin/nuclear_license_gen
```

---

## 🔐 License System Setup

### Step 1: Generate Author License

```bash
cd /home/kali/Desktop/nuclear-kernel-v8.9.0

# Create licenses directory
mkdir -p licenses

# Generate author unlimited license for lxkhanin
LD_LIBRARY_PATH=./lib ./bin/nuclear_license_gen \
    --author \
    --output=licenses/lxkhanin_author_unlimited.nuclear

# Expected output:
# 🔥 GENERATING NUCLEAR AUTHOR LICENSE 🔥
# =========================================
# ✅ Author License Generated Successfully!
# 📄 License ID: LXKHANIN_NUCLEAR_AUTHOR_UNLIMITED_2024
# 👤 User: lxkhanin
# 🎯 Type: AUTHOR (UNLIMITED)
# ⏰ Expires: NEVER
# 🔧 Features: ALL UNLOCKED
```

### Step 2: Validate License

```bash
# Test license validation
LD_LIBRARY_PATH=./lib ./bin/nuclear_license_gen \
    --validate=licenses/lxkhanin_author_unlimited.nuclear

# Expected output:
# 🔍 VALIDATING NUCLEAR LICENSE 🔍
# =================================
# 📄 License ID: LXKHANIN_NUCLEAR_AUTHOR_UNLIMITED_2024
# 👤 User: lxkhanin
# 🎯 Type: AUTHOR
# ✅ License Status: VALID
# ⏰ Expiry: NEVER EXPIRES
```

### Step 3: Verify License File

```bash
# Check license file
ls -la licenses/lxkhanin_author_unlimited.nuclear
file licenses/lxkhanin_author_unlimited.nuclear
hexdump -C licenses/lxkhanin_author_unlimited.nuclear | head -10
```

---

## 🧪 System Testing

### Test 1: Kernel Initialization

Create test script: `test_kernel.py`

```python
#!/usr/bin/env python3
import ctypes
import os
from pathlib import Path

print("🧪 Testing Nuclear Kernel v8.9.0")
print("=" * 40)

# Set up environment
kernel_path = Path("/home/kali/Desktop/nuclear-kernel-v8.9.0")
os.environ['LD_LIBRARY_PATH'] = str(kernel_path / "lib")

try:
    # Load nuclear kernel
    nuclear_lib = ctypes.CDLL(str(kernel_path / "lib" / "libnuclear_kernel.so"))
    print("✅ Nuclear kernel library loaded")
    
    # Initialize kernel
    result = nuclear_lib.nuclear_kernel_init()
    if result == 0:
        print("✅ Kernel initialization: SUCCESS")
        
        # Get version
        version_func = nuclear_lib.nuclear_kernel_get_version
        version_func.restype = ctypes.c_char_p
        version = version_func().decode('utf-8')
        print(f"✅ Nuclear Kernel version: {version}")
        
        # Shutdown gracefully
        nuclear_lib.nuclear_kernel_shutdown()
        print("✅ Kernel shutdown: SUCCESS")
        
    else:
        print(f"❌ Kernel initialization failed with code: {result}")
        
except Exception as e:
    print(f"❌ Test failed: {e}")
    
print("\n🧪 Kernel test completed!")
```

Run the test:
```bash
cd /home/kali/Desktop/nuclear-kernel-v8.9.0
python3 test_kernel.py
```

### Test 2: Performance Benchmark

```bash
# Run performance test (if available in Makefile)
make performance-test

# Or manual benchmark
time LD_LIBRARY_PATH=./lib ./bin/nuclear_license_gen --help
```

### Test 3: Memory Test

```bash
# Run memory leak detection (if debug build available)
make memory-test

# Or use valgrind manually
valgrind --tool=memcheck --leak-check=full \
    --show-leak-kinds=all \
    ./test_kernel.py
```

---

## 🔗 Framework Integration

### Step 1: Install Destruction III Framework

```bash
# Ensure framework is available
ls -la /home/kali/Desktop/destruction-III-framework/

# Check activator script
ls -la /home/kali/Desktop/destruction-III-framework/nuclear_kernel_activator.py
```

### Step 2: Run Integration

```bash
cd /home/kali/Desktop/destruction-III-framework

# Run the nuclear kernel activator
python3 nuclear_kernel_activator.py

# Expected complete output:
# 🚀 NUCLEAR KERNEL ACTIVATOR v8.9.0 🚀
# ═══════════════════════════════════════
# 
# ✅ Nuclear Kernel v8.9.0 initialized successfully!
# ✅ Author license validated successfully!
# ✅ Framework Tools: 12/12 operational
# ✅ Security Modules: 25/25 operational
# ✅ AI Engines: 11/11 operational
# 
# 🔥 DESTRUCTION III FRAMEWORK WITH NUCLEAR KERNEL v8.9.0 IS READY!
```

### Step 3: Verify Integration Status

```bash
# Check activation status file
cat /home/kali/Desktop/destruction-III-framework/data/activation_status.json

# Should show:
# {
#   "kernel": true,
#   "license": true,
#   "tools": { ... },
#   "modules": { ... },
#   "engines": { ... },
#   "overall": true,
#   "timestamp": "2024-09-20T...",
#   "version": "8.9.0",
#   "author": "lxkhanin"
# }
```

---

## 🚨 Troubleshooting

### Issue 1: Compilation Fails

**Error**: `make: *** Bus error` or compilation errors

**Solutions**:
```bash
# Solution A: Update build tools
sudo apt update && sudo apt upgrade -y
sudo apt install --reinstall build-essential g++ make

# Solution B: Use manual compilation
cd /home/kali/Desktop/nuclear-kernel-v8.9.0
rm -rf build lib bin
mkdir -p build lib bin

# Follow manual build steps from Step 2 above
```

### Issue 2: Library Loading Fails

**Error**: `error while loading shared libraries`

**Solutions**:
```bash
# Solution A: Set LD_LIBRARY_PATH permanently
echo 'export LD_LIBRARY_PATH=/home/kali/Desktop/nuclear-kernel-v8.9.0/lib:$LD_LIBRARY_PATH' >> ~/.bashrc
source ~/.bashrc

# Solution B: Use absolute paths
LD_LIBRARY_PATH=/home/kali/Desktop/nuclear-kernel-v8.9.0/lib \
    /home/kali/Desktop/nuclear-kernel-v8.9.0/bin/nuclear_license_gen --help
```

### Issue 3: License Validation Fails

**Error**: License shows as invalid or not found

**Solutions**:
```bash
# Check license file exists
ls -la /home/kali/Desktop/nuclear-kernel-v8.9.0/licenses/lxkhanin_author_unlimited.nuclear

# Regenerate license if missing
cd /home/kali/Desktop/nuclear-kernel-v8.9.0
LD_LIBRARY_PATH=./lib ./bin/nuclear_license_gen \
    --author --output=licenses/lxkhanin_author_unlimited.nuclear

# Test with full paths
LD_LIBRARY_PATH=/home/kali/Desktop/nuclear-kernel-v8.9.0/lib \
    /home/kali/Desktop/nuclear-kernel-v8.9.0/bin/nuclear_license_gen \
    --validate=/home/kali/Desktop/nuclear-kernel-v8.9.0/licenses/lxkhanin_author_unlimited.nuclear
```

### Issue 4: Python Integration Problems

**Error**: `ctypes` cannot find library or import errors

**Solutions**:
```python
# Use absolute paths in Python
import os
import ctypes
from pathlib import Path

kernel_path = Path("/home/kali/Desktop/nuclear-kernel-v8.9.0").absolute()
lib_path = kernel_path / "lib" / "libnuclear_kernel.so"

# Ensure library path is set
os.environ['LD_LIBRARY_PATH'] = str(kernel_path / "lib")

# Load with absolute path
nuclear_lib = ctypes.CDLL(str(lib_path))
```

### Issue 5: Permission Errors

**Error**: Permission denied errors

**Solutions**:
```bash
# Fix ownership
sudo chown -R $USER:$USER /home/kali/Desktop/nuclear-kernel-v8.9.0/

# Fix permissions
chmod -R 755 /home/kali/Desktop/nuclear-kernel-v8.9.0/
chmod +x /home/kali/Desktop/nuclear-kernel-v8.9.0/bin/*
```

---

## ✅ Installation Verification Checklist

### Core Components

- [ ] **Source Code**: `src/nuclear_kernel.cpp` exists and readable
- [ ] **Headers**: `include/nuclear_kernel.h` exists and readable  
- [ ] **Makefile**: `Makefile` exists and executable
- [ ] **Build Directory**: `build/` directory created
- [ ] **Library Directory**: `lib/` directory created
- [ ] **Binary Directory**: `bin/` directory created
- [ ] **License Directory**: `licenses/` directory created

### Compiled Components

- [ ] **Shared Library**: `lib/libnuclear_kernel.so` exists (~68KB)
- [ ] **License Generator**: `bin/nuclear_license_gen` exists and executable
- [ ] **Object Files**: `build/nuclear_kernel.o` exists
- [ ] **Library Dependencies**: `ldd` shows proper linking

### License System

- [ ] **Author License File**: `licenses/lxkhanin_author_unlimited.nuclear` (184 bytes)
- [ ] **License Generation**: Generator creates valid licenses  
- [ ] **License Validation**: Validator confirms license is valid
- [ ] **License Content**: License shows AUTHOR type, lxkhanin user, never expires

### Integration

- [ ] **Python Loading**: ctypes can load the library
- [ ] **Kernel Init**: `nuclear_kernel_init()` returns 0
- [ ] **Version Check**: `nuclear_kernel_get_version()` returns "8.9.0"
- [ ] **Kernel Shutdown**: `nuclear_kernel_shutdown()` works without errors
- [ ] **Framework Integration**: Activator script completes successfully

### Environment

- [ ] **LD_LIBRARY_PATH**: Set correctly for library loading
- [ ] **File Permissions**: All files have correct permissions
- [ ] **Directory Structure**: All directories in correct hierarchy
- [ ] **System Dependencies**: All required packages installed

---

## 🎯 Post-Installation

### Set Up Environment Variables

Add to `~/.bashrc` or `~/.zshrc`:

```bash
# Nuclear Kernel v8.9.0 Environment
export NUCLEAR_KERNEL_ROOT="/home/kali/Desktop/nuclear-kernel-v8.9.0"
export LD_LIBRARY_PATH="$NUCLEAR_KERNEL_ROOT/lib:$LD_LIBRARY_PATH"
export PATH="$NUCLEAR_KERNEL_ROOT/bin:$PATH"

# Nuclear Kernel aliases
alias nuclear-kernel-version='nuclear_license_gen --help | head -3'
alias nuclear-kernel-validate='nuclear_license_gen --validate=$NUCLEAR_KERNEL_ROOT/licenses/lxkhanin_author_unlimited.nuclear'
alias nuclear-kernel-test='python3 $NUCLEAR_KERNEL_ROOT/test_kernel.py'
```

### Create Desktop Shortcuts

```bash
# Create activation shortcut
cat > ~/Desktop/nuclear-kernel-activator.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Nuclear Kernel Activator
Comment=Activate Nuclear Kernel v8.9.0 with Destruction III Framework
Exec=python3 /home/kali/Desktop/destruction-III-framework/nuclear_kernel_activator.py
Icon=utilities-terminal
Terminal=true
Categories=Development;
EOF

chmod +x ~/Desktop/nuclear-kernel-activator.desktop
```

### Documentation Access

```bash
# Quick documentation access
alias nuclear-docs='cd /home/kali/Desktop/nuclear-kernel-v8.9.0/docs && ls -la'
alias nuclear-readme='cat /home/kali/Desktop/nuclear-kernel-v8.9.0/docs/README.md'
alias nuclear-guide='cat /home/kali/Desktop/NUCLEAR_KERNEL_v8.9.0_INTEGRATION_GUIDE.md'
```

---

## 🎉 Installation Complete!

If all steps completed successfully, you now have:

✅ **Nuclear Kernel v8.9.0** fully compiled and operational  
✅ **Author License** generated and validated for lxkhanin  
✅ **Framework Integration** tested and working  
✅ **Complete Documentation** available for reference  
✅ **Environment Setup** configured for easy access  

### Next Steps

1. **Run the full system**: `python3 /home/kali/Desktop/destruction-III-framework/nuclear_kernel_activator.py`
2. **Explore the framework**: Check all tools, modules, and AI engines
3. **Read documentation**: Review guides for advanced usage
4. **Start security research**: Begin using the enhanced neural-quantum capabilities

---

**🔥 Nuclear Kernel v8.9.0 "Neural Nexus Quantum" Installation Complete!**

*Enhanced Neural-Quantum Processing Ready for Advanced Security Research*

**Author**: lxkhanin  
**Email**: kali3rrlinux@gmail.com  
**Website**: [hypercorp.netlify.app](https://hypercorp.netlify.app)

---

**Last Updated**: 2024-09-20  
**Installation Guide Version**: 1.0  
**Nuclear Kernel Version**: 8.9.0 "Neural Nexus Quantum"
