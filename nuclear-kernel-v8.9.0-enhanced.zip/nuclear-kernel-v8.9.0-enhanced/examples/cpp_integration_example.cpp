/**
 * Nuclear Kernel v8.9.0 C++ Integration Example
 * Author: Lxkhaninkali
 */

#include <iostream>
#include <string>
#include "../integration/nuclear_kernel_cpp.h"

int main() {
    std::cout << "🚀 Nuclear Kernel v8.9.0 C++ Integration Example\n";
    std::cout << "Author: Lxkhaninkali\n\n";
    
    // Initialize nuclear kernel
    std::cout << "Initializing nuclear kernel...\n";
    int result = nuclear_kernel_init();
    
    if (result == 0) {
        std::cout << "✅ Nuclear kernel initialized successfully!\n";
        
        // Get version
        const char* version = nuclear_kernel_get_version();
        std::cout << "🔸 Version: " << (version ? version : "8.9.0") << "\n";
        
        // Get status
        int status = nuclear_kernel_status();
        std::cout << "🔸 Status: " << status << "\n";
        
        // Initialize quantum processor
        std::cout << "\nInitializing quantum processor...\n";
        if (nuclear_quantum_processor_init() == 0) {
            std::cout << "✅ Quantum processor initialized!\n";
        }
        
        // Shutdown
        std::cout << "\nShutting down nuclear kernel...\n";
        nuclear_kernel_shutdown();
        std::cout << "✅ Nuclear kernel shutdown complete\n";
        
    } else {
        std::cout << "❌ Nuclear kernel initialization failed: " << result << "\n";
        return 1;
    }
    
    return 0;
}
