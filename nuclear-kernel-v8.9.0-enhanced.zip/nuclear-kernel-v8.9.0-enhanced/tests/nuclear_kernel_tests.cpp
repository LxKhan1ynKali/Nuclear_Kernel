/**
 * Nuclear Kernel v1.0 - Comprehensive Test Suite
 * 
 * Advanced testing framework for Nuclear Kernel components
 * Author: lxkhanin
 * License: Nuclear Research License
 */

#include "../include/nuclear_kernel.h"
#include <iostream>
#include <cassert>
#include <chrono>
#include <vector>
#include <string>

using namespace nuclear;

class NuclearKernelTestSuite {
private:
    int tests_run_;
    int tests_passed_;
    int tests_failed_;
    
public:
    NuclearKernelTestSuite() : tests_run_(0), tests_passed_(0), tests_failed_(0) {}
    
    void run_all_tests() {
        std::cout << "🧪 NUCLEAR KERNEL COMPREHENSIVE TEST SUITE 🧪" << std::endl;
        std::cout << "================================================" << std::endl;
        std::cout << std::endl;
        
        // Core kernel tests
        test_kernel_initialization();
        test_kernel_lifecycle();
        test_memory_management_advanced();
        test_licensing_system();
        test_module_system();
        test_firmware_system();
        test_system_calls();
        test_process_management();
        test_performance_stress();
        test_error_handling();
        
        // Print results
        print_test_results();
    }
    
private:
    void test_kernel_initialization() {
        std::cout << "🔬 Testing Kernel Initialization..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        
        // Test initial state
        run_test("Initial state should be OFFLINE", 
                 kernel->get_state() == KernelState::OFFLINE);
        
        // Test initialization
        int result = kernel->initialize();
        run_test("Kernel initialization should succeed", result == NK_SUCCESS);
        run_test("State should be ACTIVE after init", 
                 kernel->get_state() == KernelState::ACTIVE);
        
        // Test version
        std::string version = kernel->get_version_string();
        run_test("Version should be 1.0.0", version == "1.0.0");
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_kernel_lifecycle() {
        std::cout << "🔬 Testing Kernel Lifecycle..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        
        // Multiple init/shutdown cycles
        for (int i = 0; i < 5; ++i) {
            int init_result = kernel->initialize();
            run_test("Repeated init should work", init_result == NK_SUCCESS);
            
            int shutdown_result = kernel->shutdown();
            run_test("Shutdown should work", shutdown_result == NK_SUCCESS);
            run_test("State should be OFFLINE after shutdown",
                     kernel->get_state() == KernelState::OFFLINE);
        }
        
        std::cout << std::endl;
    }
    
    void test_memory_management_advanced() {
        std::cout << "🔬 Testing Advanced Memory Management..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test various allocation sizes
        std::vector<void*> allocations;
        std::vector<size_t> sizes = {64, 256, 1024, 4096, 8192, 16384};
        
        for (size_t size : sizes) {
            void* ptr = kernel->allocate_memory(size);
            run_test("Memory allocation should succeed", ptr != nullptr);
            if (ptr) {
                allocations.push_back(ptr);
            }
        }
        
        // Test memory usage tracking
        size_t usage_before = kernel->get_memory_usage();
        run_test("Memory usage should be > 0", usage_before > 0);
        
        // Free half the allocations
        for (size_t i = 0; i < allocations.size() / 2; ++i) {
            int result = kernel->free_memory(allocations[i]);
            run_test("Memory free should succeed", result == NK_SUCCESS);
        }
        
        size_t usage_after = kernel->get_memory_usage();
        run_test("Memory usage should decrease", usage_after < usage_before);
        
        // Free remaining allocations
        for (size_t i = allocations.size() / 2; i < allocations.size(); ++i) {
            kernel->free_memory(allocations[i]);
        }
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_licensing_system() {
        std::cout << "🔬 Testing Licensing System..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test license validation (may not have license installed)
        LicenseType type = kernel->get_license_type();
        run_test("License type should be valid", 
                 type >= LicenseType::TRIAL && type <= LicenseType::AUTHOR);
        
        // Test license validation function
        bool valid = kernel->validate_license();
        run_test("License validation should not crash", true); // Always pass, just test it doesn't crash
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_module_system() {
        std::cout << "🔬 Testing Module System..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test getting loaded modules (should be empty initially)
        auto modules = kernel->get_loaded_modules();
        run_test("Initially no modules should be loaded", modules.empty());
        
        // Test invalid module loading
        int result = kernel->load_module("nonexistent_module.so");
        run_test("Loading nonexistent module should fail", result != NK_SUCCESS);
        
        // Test unloading nonexistent module
        result = kernel->unload_module("nonexistent_module");
        run_test("Unloading nonexistent module should fail", result != NK_SUCCESS);
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_firmware_system() {
        std::cout << "🔬 Testing Firmware System..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test getting loaded firmware (should be empty initially)
        auto firmware = kernel->get_loaded_firmware();
        run_test("Initially no firmware should be loaded", firmware.empty());
        
        // Test invalid firmware loading
        int result = kernel->load_firmware("nonexistent_firmware.bin");
        run_test("Loading nonexistent firmware should fail", result != NK_SUCCESS);
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_system_calls() {
        std::cout << "🔬 Testing System Calls..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test basic system calls
        int result = kernel->syscall(0); // sys_null
        run_test("sys_null should succeed", result == NK_SUCCESS);
        
        result = kernel->syscall(1); // sys_getpid
        run_test("sys_getpid should return valid PID", result > 0);
        
        // Test invalid system call
        result = kernel->syscall(999);
        run_test("Invalid syscall should handle gracefully", true); // Don't crash
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_process_management() {
        std::cout << "🔬 Testing Process Management..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test process creation
        uint32_t pid1 = kernel->create_process("test_process_1", nullptr);
        run_test("Process creation should succeed", pid1 > 0);
        
        uint32_t pid2 = kernel->create_process("test_process_2", nullptr);
        run_test("Second process creation should succeed", pid2 > 0);
        run_test("PIDs should be different", pid1 != pid2);
        
        // Test process list
        auto processes = kernel->get_process_list();
        run_test("Process list should contain created processes", processes.size() >= 2);
        
        // Test process termination
        int result = kernel->terminate_process(pid1);
        run_test("Process termination should succeed", result == NK_SUCCESS);
        
        kernel->terminate_process(pid2);
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_performance_stress() {
        std::cout << "🔬 Testing Performance Under Stress..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        auto start_time = std::chrono::high_resolution_clock::now();
        
        // Stress test: many allocations/deallocations
        std::vector<void*> ptrs;
        for (int i = 0; i < 1000; ++i) {
            void* ptr = kernel->allocate_memory(1024);
            if (ptr) {
                ptrs.push_back(ptr);
            }
        }
        
        run_test("Should handle 1000 allocations", ptrs.size() == 1000);
        
        // Free all
        for (void* ptr : ptrs) {
            kernel->free_memory(ptr);
        }
        
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
        
        run_test("Performance test should complete quickly", duration.count() < 5000); // Under 5 seconds
        
        std::cout << "  ⚡ Stress test completed in " << duration.count() << " ms" << std::endl;
        
        kernel->shutdown();
        std::cout << std::endl;
    }
    
    void test_error_handling() {
        std::cout << "🔬 Testing Error Handling..." << std::endl;
        
        auto kernel = std::make_unique<Kernel>();
        kernel->initialize();
        
        // Test null pointer handling
        int result = kernel->free_memory(nullptr);
        run_test("Free nullptr should handle gracefully", result != NK_SUCCESS);
        
        // Test double initialization
        result = kernel->initialize();
        run_test("Double initialization should handle gracefully", result != NK_SUCCESS);
        
        // Test operations on shutdown kernel
        kernel->shutdown();
        
        void* ptr = kernel->allocate_memory(1024);
        run_test("Allocation after shutdown should fail", ptr == nullptr);
        
        std::cout << std::endl;
    }
    
    void run_test(const std::string& test_name, bool condition) {
        tests_run_++;
        if (condition) {
            tests_passed_++;
            std::cout << "  ✅ " << test_name << std::endl;
        } else {
            tests_failed_++;
            std::cout << "  ❌ " << test_name << std::endl;
        }
    }
    
    void print_test_results() {
        std::cout << "================================================" << std::endl;
        std::cout << "🧪 TEST RESULTS SUMMARY 🧪" << std::endl;
        std::cout << "================================================" << std::endl;
        std::cout << "Total Tests: " << tests_run_ << std::endl;
        std::cout << "✅ Passed: " << tests_passed_ << std::endl;
        std::cout << "❌ Failed: " << tests_failed_ << std::endl;
        
        double success_rate = (static_cast<double>(tests_passed_) / tests_run_) * 100.0;
        std::cout << "📊 Success Rate: " << std::fixed << std::setprecision(1) << success_rate << "%" << std::endl;
        
        if (tests_failed_ == 0) {
            std::cout << "🎉 ALL TESTS PASSED! Nuclear Kernel is ready for deployment!" << std::endl;
        } else {
            std::cout << "⚠️ Some tests failed. Review and fix issues before deployment." << std::endl;
        }
        std::cout << "================================================" << std::endl;
    }
};

int main() {
    NuclearKernelTestSuite test_suite;
    test_suite.run_all_tests();
    return 0;
}
