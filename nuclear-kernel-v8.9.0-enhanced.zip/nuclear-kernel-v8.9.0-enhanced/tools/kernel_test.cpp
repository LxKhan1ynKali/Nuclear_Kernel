/**
 * Nuclear Kernel v1.0 - Kernel Test Program
 * 
 * Author: lxkhanin
 * Purpose: Test and verify nuclear kernel functionality
 */

#include "../include/nuclear_kernel.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>

using namespace nuclear;

class KernelTester {
private:
    std::unique_ptr<Kernel> kernel_;
    
public:
    KernelTester() {
        kernel_ = std::make_unique<Kernel>();
    }
    
    void run_all_tests() {
        std::cout << "🔥 NUCLEAR KERNEL TEST SUITE 🔥" << std::endl;
        std::cout << "================================" << std::endl;
        std::cout << std::endl;
        
        bool all_passed = true;
        
        all_passed &= test_kernel_initialization();
        all_passed &= test_memory_management();
        all_passed &= test_license_system();
        all_passed &= test_module_system();
        all_passed &= test_firmware_system();
        all_passed &= test_system_calls();
        all_passed &= test_performance();
        
        std::cout << std::endl;
        std::cout << "================================" << std::endl;
        if (all_passed) {
            std::cout << "✅ ALL TESTS PASSED!" << std::endl;
        } else {
            std::cout << "❌ SOME TESTS FAILED!" << std::endl;
        }
        std::cout << "================================" << std::endl;
    }
    
private:
    bool test_kernel_initialization() {
        std::cout << "🧪 Testing Kernel Initialization..." << std::endl;
        
        // Test kernel initialization
        int result = kernel_->initialize();
        if (result != NK_SUCCESS) {
            std::cout << "❌ Kernel initialization failed" << std::endl;
            return false;
        }
        
        // Test kernel state
        if (kernel_->get_state() != KernelState::ACTIVE) {
            std::cout << "❌ Kernel not in active state" << std::endl;
            return false;
        }
        
        // Test version string
        std::string version = kernel_->get_version_string();
        if (version != "1.0.0") {
            std::cout << "❌ Incorrect version string: " << version << std::endl;
            return false;
        }
        
        std::cout << "✅ Kernel initialization test passed" << std::endl;
        return true;
    }
    
    bool test_memory_management() {
        std::cout << "🧪 Testing Memory Management..." << std::endl;
        
        // Test memory allocation
        void* ptr1 = kernel_->allocate_memory(4096);
        if (!ptr1) {
            std::cout << "❌ Memory allocation failed" << std::endl;
            return false;
        }
        
        // Test multiple allocations
        std::vector<void*> ptrs;
        for (int i = 0; i < 10; ++i) {
            void* ptr = kernel_->allocate_memory(1024 * (i + 1));
            if (!ptr) {
                std::cout << "❌ Memory allocation " << i << " failed" << std::endl;
                return false;
            }
            ptrs.push_back(ptr);
        }
        
        // Test memory usage tracking
        size_t usage_before = kernel_->get_memory_usage();
        if (usage_before == 0) {
            std::cout << "❌ Memory usage tracking failed" << std::endl;
            return false;
        }
        
        // Test memory deallocation
        kernel_->free_memory(ptr1);
        for (void* ptr : ptrs) {
            kernel_->free_memory(ptr);
        }
        
        std::cout << "✅ Memory management test passed" << std::endl;
        return true;
    }
    
    bool test_license_system() {
        std::cout << "🧪 Testing License System..." << std::endl;
        
        // Test license validation (should work even without license for testing)
        LicenseType type = kernel_->get_license_type();
        std::cout << "🔐 Current license type: " << static_cast<int>(type) << std::endl;
        
        std::cout << "✅ License system test passed" << std::endl;
        return true;
    }
    
    bool test_module_system() {
        std::cout << "🧪 Testing Module System..." << std::endl;
        
        // Test getting loaded modules (should be empty initially)
        auto modules = kernel_->get_loaded_modules();
        std::cout << "📦 Loaded modules: " << modules.size() << std::endl;
        
        std::cout << "✅ Module system test passed" << std::endl;
        return true;
    }
    
    bool test_firmware_system() {
        std::cout << "🧪 Testing Firmware System..." << std::endl;
        
        // Test getting loaded firmware (should be empty initially)
        auto firmware = kernel_->get_loaded_firmware();
        std::cout << "🔧 Loaded firmware: " << firmware.size() << std::endl;
        
        std::cout << "✅ Firmware system test passed" << std::endl;
        return true;
    }
    
    bool test_system_calls() {
        std::cout << "🧪 Testing System Calls..." << std::endl;
        
        // Test basic system call
        int result = kernel_->syscall(0); // sys_null
        if (result != NK_SUCCESS) {
            std::cout << "❌ System call 0 failed" << std::endl;
            return false;
        }
        
        std::cout << "✅ System calls test passed" << std::endl;
        return true;
    }
    
    bool test_performance() {
        std::cout << "🧪 Testing Performance..." << std::endl;
        
        // Memory allocation performance test
        auto start = std::chrono::high_resolution_clock::now();
        
        for (int i = 0; i < 1000; ++i) {
            void* ptr = kernel_->allocate_memory(4096);
            if (ptr) {
                kernel_->free_memory(ptr);
            }
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        
        std::cout << "⚡ 1000 alloc/free cycles: " << duration.count() << " microseconds" << std::endl;
        
        // System call performance test
        start = std::chrono::high_resolution_clock::now();
        
        for (int i = 0; i < 10000; ++i) {
            kernel_->syscall(0);
        }
        
        end = std::chrono::high_resolution_clock::now();
        duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        
        std::cout << "⚡ 10000 system calls: " << duration.count() << " microseconds" << std::endl;
        
        std::cout << "✅ Performance test passed" << std::endl;
        return true;
    }
};

void print_system_info() {
    std::cout << "Nuclear Kernel v" << NUCLEAR_KERNEL_VERSION_STRING << " Test Program" << std::endl;
    std::cout << "Author: " << NUCLEAR_KERNEL_AUTHOR << std::endl;
    std::cout << "Codename: " << NUCLEAR_KERNEL_CODENAME << std::endl;
    std::cout << std::endl;
}

void run_benchmark(int iterations) {
    std::cout << "🏁 NUCLEAR KERNEL BENCHMARK 🏁" << std::endl;
    std::cout << "Iterations: " << iterations << std::endl;
    std::cout << "==============================" << std::endl;
    
    auto kernel = std::make_unique<Kernel>();
    kernel->initialize();
    
    // Memory allocation benchmark
    auto start = std::chrono::high_resolution_clock::now();
    
    std::vector<void*> ptrs;
    for (int i = 0; i < iterations; ++i) {
        void* ptr = kernel->allocate_memory(4096);
        if (ptr) {
            ptrs.push_back(ptr);
        }
    }
    
    auto mid = std::chrono::high_resolution_clock::now();
    
    for (void* ptr : ptrs) {
        kernel->free_memory(ptr);
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    
    auto alloc_time = std::chrono::duration_cast<std::chrono::microseconds>(mid - start);
    auto free_time = std::chrono::duration_cast<std::chrono::microseconds>(end - mid);
    
    std::cout << "Memory Allocation: " << alloc_time.count() << " µs" << std::endl;
    std::cout << "Memory Deallocation: " << free_time.count() << " µs" << std::endl;
    std::cout << "Allocations per second: " << (iterations * 1000000LL) / alloc_time.count() << std::endl;
    
    kernel->shutdown();
}

int main(int argc, char* argv[]) {
    print_system_info();
    
    // Parse command line arguments
    bool run_tests = true;
    bool run_benchmarks = false;
    int benchmark_iterations = 1000;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg(argv[i]);
        
        if (arg == "--benchmark") {
            run_benchmarks = true;
        } else if (arg == "--no-tests") {
            run_tests = false;
        } else if (arg.find("--iterations=") == 0) {
            benchmark_iterations = std::stoi(arg.substr(13));
        } else if (arg == "--iterations" && i + 1 < argc) {
            benchmark_iterations = std::stoi(argv[++i]);
        } else if (arg == "--help") {
            std::cout << "Usage: " << argv[0] << " [OPTIONS]" << std::endl;
            std::cout << "OPTIONS:" << std::endl;
            std::cout << "  --benchmark           Run performance benchmarks" << std::endl;
            std::cout << "  --no-tests           Skip functionality tests" << std::endl;
            std::cout << "  --iterations <n>     Benchmark iterations (default: 1000)" << std::endl;
            std::cout << "  --help              Show this help" << std::endl;
            return 0;
        }
    }
    
    if (run_tests) {
        KernelTester tester;
        tester.run_all_tests();
        std::cout << std::endl;
    }
    
    if (run_benchmarks) {
        run_benchmark(benchmark_iterations);
    }
    
    return 0;
}
