/**
 * Nuclear Kernel v1.0 - License Generator Tool
 * 
 * Author: lxkhanin
 * Purpose: Generate nuclear licenses for users and author unlimited license
 */

#include "../include/nuclear_kernel.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <iomanip>
#include <sstream>
#include <sys/utsname.h>

using namespace nuclear;

class NuclearLicenseGenerator {
private:
    std::mt19937_64 rng_;
    
public:
    NuclearLicenseGenerator() {
        // Initialize random number generator
        auto seed = std::chrono::high_resolution_clock::now().time_since_epoch().count();
        rng_.seed(seed);
    }
    
    /**
     * Generate Author Unlimited License for lxkhanin
     */
    bool generate_author_license(const std::string& output_path) {
        std::cout << "🔥 GENERATING NUCLEAR AUTHOR LICENSE 🔥" << std::endl;
        std::cout << "=========================================" << std::endl;
        
        nuclear_license license;
        memset(&license, 0, sizeof(license));
        
        // Author license details
        strcpy(license.license_id, "LXKHANIN_NUCLEAR_AUTHOR_UNLIMITED_2024");
        license.type = LicenseType::AUTHOR;
        strcpy(license.user_id, "lxkhanin");
        
        // Timestamps
        auto now = std::chrono::system_clock::now();
        license.issued_date = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
        license.expiry_date = UINT64_MAX; // Never expires
        
        // Full feature access
        license.features = 0xFFFFFFFF;
        
        // Works on any hardware (0 = universal)
        license.hardware_fingerprint = 0;
        
        // Generate signature
        license.signature = calculate_author_signature(license);
        license.validated = true;
        
        // Write license file
        std::ofstream file(output_path, std::ios::binary);
        if (!file) {
            std::cerr << "❌ Error: Cannot create license file: " << output_path << std::endl;
            return false;
        }
        
        file.write(reinterpret_cast<const char*>(&license), sizeof(license));
        file.close();
        
        std::cout << "✅ Author License Generated Successfully!" << std::endl;
        std::cout << "📄 License ID: " << license.license_id << std::endl;
        std::cout << "👤 User: " << license.user_id << std::endl;
        std::cout << "🎯 Type: AUTHOR (UNLIMITED)" << std::endl;
        std::cout << "⏰ Expires: NEVER" << std::endl;
        std::cout << "🔧 Features: ALL UNLOCKED" << std::endl;
        std::cout << "💾 Saved to: " << output_path << std::endl;
        
        return true;
    }
    
    /**
     * Generate Standard User License
     */
    bool generate_user_license(const std::string& user_id, 
                              LicenseType type,
                              uint32_t duration_days,
                              uint32_t features,
                              const std::string& output_path) {
        
        std::cout << "🔐 GENERATING NUCLEAR USER LICENSE 🔐" << std::endl;
        std::cout << "=====================================" << std::endl;
        
        nuclear_license license;
        memset(&license, 0, sizeof(license));
        
        // Generate license ID
        std::string license_id = "NK_" + generate_license_id();
        strcpy(license.license_id, license_id.c_str());
        
        license.type = type;
        strcpy(license.user_id, user_id.c_str());
        
        // Timestamps
        auto now = std::chrono::system_clock::now();
        license.issued_date = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
        
        auto expiry = now + std::chrono::hours(24 * duration_days);
        license.expiry_date = std::chrono::duration_cast<std::chrono::seconds>(expiry.time_since_epoch()).count();
        
        // Features and hardware fingerprint
        license.features = features;
        license.hardware_fingerprint = get_hardware_fingerprint();
        
        // Generate signature
        license.signature = calculate_user_signature(license);
        license.validated = true;
        
        // Write license file
        std::ofstream file(output_path, std::ios::binary);
        if (!file) {
            std::cerr << "❌ Error: Cannot create license file: " << output_path << std::endl;
            return false;
        }
        
        file.write(reinterpret_cast<const char*>(&license), sizeof(license));
        file.close();
        
        std::cout << "✅ User License Generated Successfully!" << std::endl;
        std::cout << "📄 License ID: " << license.license_id << std::endl;
        std::cout << "👤 User: " << license.user_id << std::endl;
        std::cout << "🎯 Type: " << license_type_to_string(type) << std::endl;
        std::cout << "⏰ Valid for: " << duration_days << " days" << std::endl;
        std::cout << "🔧 Features: 0x" << std::hex << features << std::dec << std::endl;
        std::cout << "💾 Saved to: " << output_path << std::endl;
        
        return true;
    }
    
    /**
     * Validate existing license
     */
    bool validate_license(const std::string& license_path) {
        std::cout << "🔍 VALIDATING NUCLEAR LICENSE 🔍" << std::endl;
        std::cout << "=================================" << std::endl;
        
        std::ifstream file(license_path, std::ios::binary);
        if (!file) {
            std::cerr << "❌ Error: Cannot read license file: " << license_path << std::endl;
            return false;
        }
        
        nuclear_license license;
        file.read(reinterpret_cast<char*>(&license), sizeof(license));
        file.close();
        
        std::cout << "📄 License ID: " << license.license_id << std::endl;
        std::cout << "👤 User: " << license.user_id << std::endl;
        std::cout << "🎯 Type: " << license_type_to_string(license.type) << std::endl;
        
        // Check expiry
        auto now = std::chrono::system_clock::now();
        auto current_time = std::chrono::duration_cast<std::chrono::seconds>(now.time_since_epoch()).count();
        
        if (license.type != LicenseType::AUTHOR && license.expiry_date < static_cast<uint64_t>(current_time)) {
            std::cout << "❌ License Status: EXPIRED" << std::endl;
            return false;
        }
        
        // Verify signature
        uint64_t expected_signature;
        if (license.type == LicenseType::AUTHOR) {
            expected_signature = calculate_author_signature(license);
        } else {
            expected_signature = calculate_user_signature(license);
        }
        
        if (license.signature != expected_signature) {
            std::cout << "❌ License Status: INVALID SIGNATURE" << std::endl;
            return false;
        }
        
        std::cout << "✅ License Status: VALID" << std::endl;
        if (license.type == LicenseType::AUTHOR) {
            std::cout << "⏰ Expiry: NEVER EXPIRES" << std::endl;
        } else {
            auto expiry_time = std::chrono::system_clock::from_time_t(license.expiry_date);
            auto time_t = std::chrono::system_clock::to_time_t(expiry_time);
            std::cout << "⏰ Expires: " << std::ctime(&time_t);
        }
        
        return true;
    }

private:
    std::string generate_license_id() {
        std::stringstream ss;
        ss << std::hex << std::uppercase;
        for (int i = 0; i < 8; ++i) {
            ss << (rng_() % 16);
        }
        return ss.str();
    }
    
    uint64_t get_hardware_fingerprint() {
        // Get hardware fingerprint for current system
        struct utsname sys_info;
        uname(&sys_info);
        
        std::string fingerprint_data = std::string(sys_info.sysname) + 
                                      std::string(sys_info.machine) +
                                      "nuclear_kernel_lxkhanin";
        
        uint64_t fingerprint = 0;
        for (char c : fingerprint_data) {
            fingerprint = (fingerprint << 8) | static_cast<uint8_t>(c);
        }
        
        return fingerprint;
    }
    
    uint64_t calculate_author_signature(const nuclear_license& license) {
        // Author signature calculation
        std::string sig_data = std::string(license.license_id) + 
                              std::string(license.user_id) + 
                              "lxkhanin_nuclear_master_2024";
        
        uint64_t signature = 0x1337DEADBEEF;
        for (char c : sig_data) {
            signature = ((signature << 5) + signature) + static_cast<uint8_t>(c);
        }
        
        return signature;
    }
    
    uint64_t calculate_user_signature(const nuclear_license& license) {
        // User signature calculation
        std::string sig_data = std::string(license.license_id) + 
                              std::string(license.user_id) + 
                              std::to_string(license.expiry_date) +
                              "nuclear_kernel_user_2024";
        
        uint64_t signature = 0xDEADBEEF1337;
        for (char c : sig_data) {
            signature = ((signature << 3) + signature) ^ static_cast<uint8_t>(c);
        }
        
        return signature;
    }
    
    std::string license_type_to_string(LicenseType type) {
        switch (type) {
            case LicenseType::TRIAL: return "TRIAL";
            case LicenseType::STANDARD: return "STANDARD";
            case LicenseType::PROFESSIONAL: return "PROFESSIONAL";
            case LicenseType::UNLIMITED: return "UNLIMITED";
            case LicenseType::AUTHOR: return "AUTHOR";
            default: return "UNKNOWN";
        }
    }
};

void print_usage(const char* prog_name) {
    std::cout << "Nuclear Kernel v1.0 - License Generator" << std::endl;
    std::cout << "Author: lxkhanin" << std::endl;
    std::cout << "======================================" << std::endl;
    std::cout << std::endl;
    std::cout << "Usage: " << prog_name << " [OPTIONS]" << std::endl;
    std::cout << std::endl;
    std::cout << "OPTIONS:" << std::endl;
    std::cout << "  --author                    Generate author unlimited license" << std::endl;
    std::cout << "  --user <user_id>           Generate user license" << std::endl;
    std::cout << "  --type <type>              License type (trial|standard|professional|unlimited)" << std::endl;
    std::cout << "  --days <days>              Duration in days (default: 30)" << std::endl;
    std::cout << "  --features <hex>           Feature mask in hex (default: 0x0F)" << std::endl;
    std::cout << "  --output <path>            Output file path" << std::endl;
    std::cout << "  --validate <path>          Validate existing license" << std::endl;
    std::cout << "  --help                     Show this help" << std::endl;
    std::cout << std::endl;
    std::cout << "EXAMPLES:" << std::endl;
    std::cout << "  " << prog_name << " --author --output=author.nuclear" << std::endl;
    std::cout << "  " << prog_name << " --user john --type standard --days 60 --output=john.nuclear" << std::endl;
    std::cout << "  " << prog_name << " --validate license.nuclear" << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }
    
    NuclearLicenseGenerator generator;
    
    // Parse command line arguments
    bool author_mode = false;
    std::string user_id;
    std::string license_type_str = "standard";
    uint32_t days = 30;
    uint32_t features = 0x0F;
    std::string output_path;
    std::string validate_path;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg(argv[i]);
        
        if (arg == "--author") {
            author_mode = true;
        } else if (arg == "--help") {
            print_usage(argv[0]);
            return 0;
        } else if (arg.find("--user=") == 0) {
            user_id = arg.substr(7);
        } else if (arg == "--user" && i + 1 < argc) {
            user_id = argv[++i];
        } else if (arg.find("--type=") == 0) {
            license_type_str = arg.substr(7);
        } else if (arg == "--type" && i + 1 < argc) {
            license_type_str = argv[++i];
        } else if (arg.find("--days=") == 0) {
            days = std::stoul(arg.substr(7));
        } else if (arg == "--days" && i + 1 < argc) {
            days = std::stoul(argv[++i]);
        } else if (arg.find("--features=") == 0) {
            features = std::stoul(arg.substr(11), nullptr, 16);
        } else if (arg == "--features" && i + 1 < argc) {
            features = std::stoul(argv[++i], nullptr, 16);
        } else if (arg.find("--output=") == 0) {
            output_path = arg.substr(9);
        } else if (arg == "--output" && i + 1 < argc) {
            output_path = argv[++i];
        } else if (arg.find("--validate=") == 0) {
            validate_path = arg.substr(11);
        } else if (arg == "--validate" && i + 1 < argc) {
            validate_path = argv[++i];
        }
    }
    
    // Validate license mode
    if (!validate_path.empty()) {
        return generator.validate_license(validate_path) ? 0 : 1;
    }
    
    // Author license mode
    if (author_mode) {
        if (output_path.empty()) {
            output_path = "lxkhanin_author_unlimited.nuclear";
        }
        return generator.generate_author_license(output_path) ? 0 : 1;
    }
    
    // User license mode
    if (!user_id.empty()) {
        if (output_path.empty()) {
            output_path = user_id + ".nuclear";
        }
        
        // Convert license type string to enum
        LicenseType type = LicenseType::STANDARD;
        if (license_type_str == "trial") {
            type = LicenseType::TRIAL;
        } else if (license_type_str == "standard") {
            type = LicenseType::STANDARD;
        } else if (license_type_str == "professional") {
            type = LicenseType::PROFESSIONAL;
        } else if (license_type_str == "unlimited") {
            type = LicenseType::UNLIMITED;
        }
        
        return generator.generate_user_license(user_id, type, days, features, output_path) ? 0 : 1;
    }
    
    std::cerr << "❌ Error: No valid action specified. Use --help for usage information." << std::endl;
    return 1;
}
