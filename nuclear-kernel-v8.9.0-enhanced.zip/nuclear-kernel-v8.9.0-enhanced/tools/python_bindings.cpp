/**
 * Nuclear Kernel v1.0 - Python Bindings
 * 
 * Python interface for the Nuclear Kernel C++ library
 * Author: lxkhanin
 * License: Nuclear Research License
 */

#include "../include/nuclear_kernel.h"
#include <Python.h>
#include <iostream>
#include <string>
#include <vector>

using namespace nuclear;

// Global kernel instance for Python bindings
static std::unique_ptr<Kernel> py_kernel = nullptr;

/**
 * Initialize Nuclear Kernel from Python
 */
static PyObject* py_nuclear_init(PyObject* self, PyObject* args) {
    if (py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel already initialized");
        return NULL;
    }
    
    py_kernel = std::make_unique<Kernel>();
    int result = py_kernel->initialize();
    
    if (result != NK_SUCCESS) {
        py_kernel.reset();
        PyErr_SetString(PyExc_RuntimeError, "Failed to initialize Nuclear Kernel");
        return NULL;
    }
    
    Py_RETURN_NONE;
}

/**
 * Shutdown Nuclear Kernel from Python
 */
static PyObject* py_nuclear_shutdown(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    py_kernel->shutdown();
    py_kernel.reset();
    
    Py_RETURN_NONE;
}

/**
 * Get kernel version
 */
static PyObject* py_nuclear_version(PyObject* self, PyObject* args) {
    return PyUnicode_FromString(NUCLEAR_KERNEL_VERSION_STRING);
}

/**
 * Get kernel state
 */
static PyObject* py_nuclear_get_state(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    KernelState state = py_kernel->get_state();
    return PyLong_FromLong(static_cast<long>(state));
}

/**
 * Allocate memory
 */
static PyObject* py_nuclear_allocate_memory(PyObject* self, PyObject* args) {
    size_t size;
    uint32_t flags = 0;
    
    if (!PyArg_ParseTuple(args, "k|I", &size, &flags)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    void* ptr = py_kernel->allocate_memory(size, flags);
    if (!ptr) {
        PyErr_SetString(PyExc_MemoryError, "Failed to allocate memory");
        return NULL;
    }
    
    return PyLong_FromVoidPtr(ptr);
}

/**
 * Free memory
 */
static PyObject* py_nuclear_free_memory(PyObject* self, PyObject* args) {
    void* ptr;
    
    if (!PyArg_ParseTuple(args, "k", &ptr)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    int result = py_kernel->free_memory(ptr);
    return PyLong_FromLong(result);
}

/**
 * Get memory usage
 */
static PyObject* py_nuclear_memory_usage(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    size_t usage = py_kernel->get_memory_usage();
    return PyLong_FromSize_t(usage);
}

/**
 * Load kernel module
 */
static PyObject* py_nuclear_load_module(PyObject* self, PyObject* args) {
    const char* module_path;
    
    if (!PyArg_ParseTuple(args, "s", &module_path)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    int result = py_kernel->load_module(std::string(module_path));
    return PyLong_FromLong(result);
}

/**
 * Unload kernel module
 */
static PyObject* py_nuclear_unload_module(PyObject* self, PyObject* args) {
    const char* module_name;
    
    if (!PyArg_ParseTuple(args, "s", &module_name)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    int result = py_kernel->unload_module(std::string(module_name));
    return PyLong_FromLong(result);
}

/**
 * Get loaded modules
 */
static PyObject* py_nuclear_get_modules(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    std::vector<std::string> modules = py_kernel->get_loaded_modules();
    
    PyObject* py_list = PyList_New(modules.size());
    if (!py_list) {
        return NULL;
    }
    
    for (size_t i = 0; i < modules.size(); ++i) {
        PyObject* py_str = PyUnicode_FromString(modules[i].c_str());
        if (!py_str) {
            Py_DECREF(py_list);
            return NULL;
        }
        PyList_SET_ITEM(py_list, i, py_str);
    }
    
    return py_list;
}

/**
 * Install license
 */
static PyObject* py_nuclear_install_license(PyObject* self, PyObject* args) {
    const char* license_path;
    
    if (!PyArg_ParseTuple(args, "s", &license_path)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    int result = py_kernel->install_license(std::string(license_path));
    return PyLong_FromLong(result);
}

/**
 * Validate license
 */
static PyObject* py_nuclear_validate_license(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    bool valid = py_kernel->validate_license();
    return PyBool_FromLong(valid ? 1 : 0);
}

/**
 * Get license type
 */
static PyObject* py_nuclear_get_license_type(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    LicenseType type = py_kernel->get_license_type();
    return PyLong_FromLong(static_cast<long>(type));
}

/**
 * Execute system call
 */
static PyObject* py_nuclear_syscall(PyObject* self, PyObject* args) {
    uint32_t syscall_num;
    uint32_t arg1 = 0, arg2 = 0, arg3 = 0;
    
    if (!PyArg_ParseTuple(args, "I|III", &syscall_num, &arg1, &arg2, &arg3)) {
        return NULL;
    }
    
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    int result = py_kernel->syscall(syscall_num, arg1, arg2, arg3);
    return PyLong_FromLong(result);
}

/**
 * Get system information
 */
static PyObject* py_nuclear_get_system_info(PyObject* self, PyObject* args) {
    if (!py_kernel) {
        PyErr_SetString(PyExc_RuntimeError, "Nuclear Kernel not initialized");
        return NULL;
    }
    
    auto info = py_kernel->get_system_info();
    
    PyObject* py_dict = PyDict_New();
    if (!py_dict) {
        return NULL;
    }
    
    for (const auto& pair : info) {
        PyObject* py_key = PyUnicode_FromString(pair.first.c_str());
        PyObject* py_value = PyUnicode_FromString(pair.second.c_str());
        
        if (!py_key || !py_value) {
            Py_XDECREF(py_key);
            Py_XDECREF(py_value);
            Py_DECREF(py_dict);
            return NULL;
        }
        
        PyDict_SetItem(py_dict, py_key, py_value);
        Py_DECREF(py_key);
        Py_DECREF(py_value);
    }
    
    return py_dict;
}

// Method definitions
static PyMethodDef NuclearMethods[] = {
    {"initialize", py_nuclear_init, METH_VARARGS, "Initialize Nuclear Kernel"},
    {"shutdown", py_nuclear_shutdown, METH_VARARGS, "Shutdown Nuclear Kernel"},
    {"version", py_nuclear_version, METH_VARARGS, "Get kernel version"},
    {"get_state", py_nuclear_get_state, METH_VARARGS, "Get kernel state"},
    {"allocate_memory", py_nuclear_allocate_memory, METH_VARARGS, "Allocate memory"},
    {"free_memory", py_nuclear_free_memory, METH_VARARGS, "Free memory"},
    {"memory_usage", py_nuclear_memory_usage, METH_VARARGS, "Get memory usage"},
    {"load_module", py_nuclear_load_module, METH_VARARGS, "Load kernel module"},
    {"unload_module", py_nuclear_unload_module, METH_VARARGS, "Unload kernel module"},
    {"get_modules", py_nuclear_get_modules, METH_VARARGS, "Get loaded modules"},
    {"install_license", py_nuclear_install_license, METH_VARARGS, "Install license"},
    {"validate_license", py_nuclear_validate_license, METH_VARARGS, "Validate license"},
    {"get_license_type", py_nuclear_get_license_type, METH_VARARGS, "Get license type"},
    {"syscall", py_nuclear_syscall, METH_VARARGS, "Execute system call"},
    {"get_system_info", py_nuclear_get_system_info, METH_VARARGS, "Get system information"},
    {NULL, NULL, 0, NULL}
};

// Module definition
static struct PyModuleDef nuclear_module = {
    PyModuleDef_HEAD_INIT,
    "nuclear_kernel",
    "Nuclear Kernel Python Bindings",
    -1,
    NuclearMethods
};

// Module initialization
PyMODINIT_FUNC PyInit_nuclear_kernel(void) {
    PyObject* module = PyModule_Create(&nuclear_module);
    if (!module) {
        return NULL;
    }
    
    // Add constants
    PyModule_AddIntConstant(module, "NK_SUCCESS", NK_SUCCESS);
    PyModule_AddIntConstant(module, "NK_ERROR_INVALID_PARAM", NK_ERROR_INVALID_PARAM);
    PyModule_AddIntConstant(module, "NK_ERROR_NO_MEMORY", NK_ERROR_NO_MEMORY);
    PyModule_AddIntConstant(module, "NK_ERROR_MODULE_NOT_FOUND", NK_ERROR_MODULE_NOT_FOUND);
    PyModule_AddIntConstant(module, "NK_ERROR_LICENSE_INVALID", NK_ERROR_LICENSE_INVALID);
    PyModule_AddIntConstant(module, "NK_ERROR_PERMISSION_DENIED", NK_ERROR_PERMISSION_DENIED);
    PyModule_AddIntConstant(module, "NK_ERROR_FIRMWARE_CORRUPT", NK_ERROR_FIRMWARE_CORRUPT);
    PyModule_AddIntConstant(module, "NK_ERROR_KERNEL_PANIC", NK_ERROR_KERNEL_PANIC);
    
    // License types
    PyModule_AddIntConstant(module, "LICENSE_TRIAL", static_cast<int>(LicenseType::TRIAL));
    PyModule_AddIntConstant(module, "LICENSE_STANDARD", static_cast<int>(LicenseType::STANDARD));
    PyModule_AddIntConstant(module, "LICENSE_PROFESSIONAL", static_cast<int>(LicenseType::PROFESSIONAL));
    PyModule_AddIntConstant(module, "LICENSE_UNLIMITED", static_cast<int>(LicenseType::UNLIMITED));
    PyModule_AddIntConstant(module, "LICENSE_AUTHOR", static_cast<int>(LicenseType::AUTHOR));
    
    // Kernel states
    PyModule_AddIntConstant(module, "STATE_OFFLINE", static_cast<int>(KernelState::OFFLINE));
    PyModule_AddIntConstant(module, "STATE_INITIALIZING", static_cast<int>(KernelState::INITIALIZING));
    PyModule_AddIntConstant(module, "STATE_LICENSE_CHECK", static_cast<int>(KernelState::LICENSE_CHECK));
    PyModule_AddIntConstant(module, "STATE_LOADING_MODULES", static_cast<int>(KernelState::LOADING_MODULES));
    PyModule_AddIntConstant(module, "STATE_LOADING_FIRMWARE", static_cast<int>(KernelState::LOADING_FIRMWARE));
    PyModule_AddIntConstant(module, "STATE_ACTIVE", static_cast<int>(KernelState::ACTIVE));
    PyModule_AddIntConstant(module, "STATE_PANIC", static_cast<int>(KernelState::PANIC));
    PyModule_AddIntConstant(module, "STATE_SHUTDOWN", static_cast<int>(KernelState::SHUTDOWN));
    
    return module;
}
