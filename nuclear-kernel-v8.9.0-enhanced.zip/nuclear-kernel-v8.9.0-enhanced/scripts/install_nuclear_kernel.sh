#!/bin/bash
# Nuclear Kernel v8.9.0 Installation Script
# Author: Lxkhaninkali

set -e

KERNEL_VERSION="8.9.0"
INSTALL_PREFIX="/usr/local"

echo "🚀 Installing Nuclear Kernel v$KERNEL_VERSION..."

# Install library
if [ -f "lib/libnuclear_kernel.so" ]; then
    sudo cp lib/libnuclear_kernel.so $INSTALL_PREFIX/lib/
    sudo ldconfig
    echo "✅ Nuclear kernel library installed"
fi

# Install headers
if [ -d "include" ]; then
    sudo cp -r include/nuclear* $INSTALL_PREFIX/include/ 2>/dev/null || true
    echo "✅ Headers installed"
fi

# Install Python module
if [ -f "integration/nuclear_kernel_python.py" ]; then
    python3 -c "import sys; print(sys.path)" | grep -q site-packages
    if [ $? -eq 0 ]; then
        SITE_PACKAGES=$(python3 -c "import site; print(site.getsitepackages()[0])")
        sudo cp integration/nuclear_kernel_python.py $SITE_PACKAGES/
        echo "✅ Python integration module installed"
    fi
fi

echo "🎯 Nuclear Kernel v$KERNEL_VERSION installation completed!"
